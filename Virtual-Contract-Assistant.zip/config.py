# Fill in with your actual credentials from IBM Cloud
DISCOVERY_API_KEY = 'your-discovery-api-key'
DISCOVERY_URL = 'your-discovery-url'
PROJECT_ID = 'your-discovery-project-id'
