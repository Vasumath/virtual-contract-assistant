# Virtual Contract Assistant

An AI-powered legal chatbot using IBM Watson Assistant and Discovery to answer contract-related queries.

## Features
- Conversational interface using Watson Assistant
- Document retrieval via Watson Discovery
- Answers contract-related questions from uploaded documents

## Setup Instructions
1. Create IBM Watson Assistant and Discovery instances on IBM Cloud.
2. Upload sample contracts to Discovery.
3. Update `config.py` with your credentials.
4. Run `app.py` to start querying.

## Requirements
- Python 3.x
- ibm-watson SDK (`pip install ibm-watson`)

## License
MIT
