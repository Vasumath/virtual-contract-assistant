from ibm_watson import DiscoveryV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import config

authenticator = IAMAuthenticator(config.DISCOVERY_API_KEY)
discovery = DiscoveryV2(version='2023-03-31', authenticator=authenticator)
discovery.set_service_url(config.DISCOVERY_URL)

query = input("Ask a contract-related question: ")
response = discovery.query(
    project_id=config.PROJECT_ID,
    natural_language_query=query,
    passages=True
).get_result()

for passage in response.get('results', []):
    print("\nAnswer:", passage['document_passages'][0]['passage_text'])
